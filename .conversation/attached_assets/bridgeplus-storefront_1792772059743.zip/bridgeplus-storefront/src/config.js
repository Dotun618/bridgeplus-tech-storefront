export const businessConfig = {
  businessName: "BridgePlus Tech",
  tagline: "Smart devices. Greater possibilities.",
  whatsappNumber: import.meta.env.VITE_WHATSAPP_NUMBER || "2349067374934",
  supportPhone: "+234 906 737 4934",
  storeAddress: "Confirm store address with BridgePlus before publishing",
  currency: "NGN",
  locale: "en-NG",
  // Set this to the real delivery charge once BridgePlus confirms it.
  // Leave at 0 if delivery is quoted case-by-case on WhatsApp.
  deliveryFee: 0,
};