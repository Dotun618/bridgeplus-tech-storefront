import React, { useMemo, useState } from "react";
import {
  ArrowDownRight, ArrowRight, AudioLines, Check, ChevronDown, ChevronRight,
  CircleHelp, Copy, Gamepad2, Headphones, Heart, Laptop, Menu, MessageCircle,
  Minus, PackageCheck, Plus, Search, ShieldCheck, ShoppingBag, Smartphone,
  Truck, X, Camera, Sparkles, Watch,
} from "lucide-react";
import { businessConfig } from "./config";
import { categories, products } from "./data/products";
import { buildOrderMessage, buildWhatsAppUrl, formatMoney, makeOrderReference } from "./utils";

const categoryIcons = {
  "Phones & tablets": Smartphone,
  "Creator tech": Camera,
  Computing: Laptop,
  Gaming: Gamepad2,
  Audio: Headphones,
  "Smart home": Watch,
  Accessories: Sparkles,
};

const initialForm = {
  name: "",
  phone: "",
  fulfilment: "delivery",
  address: "",
  deliveryNotes: "",
  customerNote: "",
};

function BrandMark() {
  return (
    <div className="brand-lockup" aria-label="BridgePlus Tech">
      <div className="brand-mark"><span>B</span><i>+</i></div>
      <div className="brand-name">BridgePlus <span>Tech</span></div>
    </div>
  );
}

function Header({ cartCount, onOpenCart, search, setSearch, onOpenMobileMenu }) {
  return (
    <header className="site-header">
      <a className="brand-link" href="#home" aria-label="BridgePlus Tech home"><BrandMark /></a>
      <nav className="desktop-nav" aria-label="Main navigation">
        <a className="nav-active" href="#home">Home</a>
        <a href="#shop">Shop</a>
        <a href="#shop" onClick={() => setSearch("phone")}>Phones</a>
        <a href="#shop" onClick={() => setSearch("laptop")}>Computing</a>
        <a href="#shop" onClick={() => setSearch("gaming")}>Gaming</a>
        <a href="#shop" onClick={() => setSearch("audio")}>Audio</a>
        <a href="#shop">Smart tech</a>
        <a href="#shop">Accessories</a>
      </nav>
      <div className="header-actions">
        <label className="header-search">
          <Search size={16} />
          <input aria-label="Search products" placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} />
          {search && <button className="icon-button clear-search" aria-label="Clear search" onClick={() => setSearch("")}><X size={14}/></button>}
        </label>
        <button className="icon-button cart-header" onClick={onOpenCart} aria-label={`Open cart, ${cartCount} items`}>
          <ShoppingBag size={20}/><span className="cart-count">{cartCount}</span>
        </button>
        <button className="icon-button mobile-menu-button" onClick={onOpenMobileMenu} aria-label="Open menu"><Menu size={22}/></button>
      </div>
    </header>
  );
}

function ProductCard({ product, onAdd, onView }) {
  return (
    <article className="product-card">
      <button className="product-image-wrap" onClick={() => onView(product)} aria-label={`View ${product.name}`}>
        {product.badge && <span className="product-badge">{product.badge}</span>}
        <img src={product.image} alt={product.name} loading="lazy" onError={(e) => { e.currentTarget.style.display = "none"; e.currentTarget.parentElement.classList.add("image-fallback"); }} />
        <span className="image-fallback-label">BridgePlus Tech</span>
        <span className="quick-view">Quick view <ArrowRight size={14}/></span>
      </button>
      <div className="product-info">
        <p className="product-brand">{product.brand}</p>
        <button className="product-title" onClick={() => onView(product)}>{product.name}</button>
        <p className="product-description">{product.description}</p>
        <div className="product-card-bottom">
          <strong>{formatMoney(product.price, businessConfig)}</strong>
          <button className="add-button" onClick={() => onAdd(product)} aria-label={`Add ${product.name} to cart`}><Plus size={17}/></button>
        </div>
      </div>
    </article>
  );
}

function ProductModal({ product, onClose, onAdd }) {
  if (!product) return null;
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <section className="product-modal modal-panel" role="dialog" aria-modal="true" aria-labelledby="product-modal-title">
        <button className="modal-close icon-button" onClick={onClose} aria-label="Close product details"><X/></button>
        <div className="modal-product-image"><img src={product.image} alt={product.name} onError={(e) => { e.currentTarget.style.display = "none"; }}/></div>
        <div className="modal-product-copy">
          <p className="eyebrow">{product.brand} · {product.category}</p>
          <h2 id="product-modal-title">{product.name}</h2>
          <p className="modal-price">{formatMoney(product.price, businessConfig)}</p>
          <p>{product.description}</p>
          {product.demo && <p className="demo-inline"><CircleHelp size={16}/> Demo listing — confirm the exact model, price and availability with BridgePlus.</p>}
          <button className="primary-button full-button" onClick={() => { onAdd(product); onClose(); }}>Add to cart <ArrowRight size={17}/></button>
        </div>
      </section>
    </div>
  );
}

function CartDrawer({ open, onClose, cart, onChangeQuantity, onRemove, subtotal, onCheckout }) {
  if (!open) return null;
  return (
    <div className="drawer-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <aside className="cart-drawer" role="dialog" aria-modal="true" aria-labelledby="cart-title">
        <div className="drawer-header">
          <div><p className="eyebrow">YOUR SELECTION</p><h2 id="cart-title">Shopping bag <span>({cart.reduce((sum, row) => sum + row.quantity, 0)})</span></h2></div>
          <button className="icon-button" onClick={onClose} aria-label="Close cart"><X/></button>
        </div>
        {cart.length === 0 ? (
          <div className="empty-cart"><div className="empty-cart-icon"><ShoppingBag size={28}/></div><h3>Your bag is waiting.</h3><p>Explore the collection and add something you love.</p><button className="primary-button" onClick={onClose}>Continue shopping <ArrowRight size={16}/></button></div>
        ) : (
          <>
            <div className="cart-items">
              {cart.map(({ product, quantity }) => (
                <div className="cart-item" key={product.id}>
                  <div className="cart-item-image"><img src={product.image} alt="" onError={(e) => {e.currentTarget.style.display="none";}}/></div>
                  <div className="cart-item-copy">
                    <p className="product-brand">{product.brand}</p>
                    <h3>{product.name}</h3>
                    <strong>{formatMoney(product.price, businessConfig)}</strong>
                    <div className="quantity-control">
                      <button aria-label={`Decrease ${product.name} quantity`} onClick={() => onChangeQuantity(product.id, quantity - 1)}><Minus size={13}/></button>
                      <span>{quantity}</span>
                      <button aria-label={`Increase ${product.name} quantity`} onClick={() => onChangeQuantity(product.id, quantity + 1)}><Plus size={13}/></button>
                    </div>
                  </div>
                  <button className="remove-link" onClick={() => onRemove(product.id)}>Remove</button>
                </div>
              ))}
            </div>
            <div className="cart-summary">
              <div className="summary-row"><span>Subtotal</span><strong>{formatMoney(subtotal, businessConfig)}</strong></div>
              <p className="muted-small">Delivery or pickup arrangements and any applicable delivery charge will be confirmed by BridgePlus.</p>
              <button className="primary-button full-button" onClick={onCheckout}>Continue to checkout <ArrowRight size={17}/></button>
              <button className="text-button full-button" onClick={onClose}>Continue shopping</button>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}

function CheckoutModal({ open, onClose, cart, subtotal, onAddOrderToClipboard }) {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [generatedOrder, setGeneratedOrder] = useState(null);
  const [copyStatus, setCopyStatus] = useState("");
  const deliveryFee = form.fulfilment === "delivery" ? businessConfig.deliveryFee : 0;
  const total = subtotal + deliveryFee;

  if (!open) return null;

  function updateField(name, value) {
    setForm((old) => ({ ...old, [name]: value }));
    setErrors((old) => ({ ...old, [name]: "" }));
    setGeneratedOrder(null);
    setCopyStatus("");
  }

  function validate() {
    const next = {};
    if (form.name.trim().length < 2) next.name = "Enter your full name.";
    const digits = form.phone.replace(/\D/g, "");
    if (digits.length < 7 || digits.length > 15) next.phone = "Enter a valid phone number.";
    if (form.fulfilment === "delivery" && form.address.trim().length < 8) next.address = "Enter a complete delivery address.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function createOrder(event) {
    event.preventDefault();
    if (!validate()) return;
    const orderRef = makeOrderReference();
    const message = buildOrderMessage({ orderRef, form, cart, subtotal, deliveryFee, total, config: businessConfig });
    const url = buildWhatsAppUrl(businessConfig.whatsappNumber, message);
    setGeneratedOrder({ orderRef, message, url });
    setCopyStatus("");
  }

  async function copyOrder() {
    if (!generatedOrder) return;
    try {
      await navigator.clipboard.writeText(generatedOrder.message);
      setCopyStatus("Order details copied. You can paste them into WhatsApp.");
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = generatedOrder.message;
      textarea.setAttribute("readonly", "");
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      const success = document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopyStatus(success ? "Order details copied. You can paste them into WhatsApp." : "Copy was blocked by this browser. Select and copy the order text below.");
    }
  }

  return (
    <div className="modal-backdrop checkout-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <section className="checkout-modal modal-panel" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
        <button className="modal-close icon-button" onClick={onClose} aria-label="Close checkout"><X/></button>
        {!generatedOrder ? (
          <>
            <div className="checkout-heading"><p className="eyebrow">ONE LAST STEP</p><h2 id="checkout-title">Checkout</h2><p>Your order request will be sent to BridgePlus on WhatsApp.</p></div>
            <div className="checkout-order-preview">
              <div><span>{cart.reduce((sum, row) => sum + row.quantity, 0)} item(s)</span><strong>{formatMoney(subtotal, businessConfig)}</strong></div>
              <p>Final stock, delivery charge and payment method are confirmed by BridgePlus.</p>
            </div>
            <form className="checkout-form" onSubmit={createOrder} noValidate>
              <label>Full name <span className="required">*</span>
                <input autoComplete="name" value={form.name} onChange={(e) => updateField("name", e.target.value)} placeholder="Your full name" aria-invalid={Boolean(errors.name)}/>
                {errors.name && <small className="field-error">{errors.name}</small>}
              </label>
              <label>Phone number <span className="required">*</span>
                <input autoComplete="tel" inputMode="tel" value={form.phone} onChange={(e) => updateField("phone", e.target.value)} placeholder="e.g. 08012345678" aria-invalid={Boolean(errors.phone)}/>
                {errors.phone && <small className="field-error">{errors.phone}</small>}
              </label>
              <fieldset className="fulfilment-options">
                <legend>How would you like to receive your order?</legend>
                <label className={`fulfilment-option ${form.fulfilment === "delivery" ? "selected" : ""}`}>
                  <input type="radio" name="fulfilment" value="delivery" checked={form.fulfilment === "delivery"} onChange={() => updateField("fulfilment", "delivery")}/>
                  <Truck size={19}/><span><strong>Home delivery</strong><small>Address required</small></span>
                </label>
                <label className={`fulfilment-option ${form.fulfilment === "pickup" ? "selected" : ""}`}>
                  <input type="radio" name="fulfilment" value="pickup" checked={form.fulfilment === "pickup"} onChange={() => updateField("fulfilment", "pickup")}/>
                  <PackageCheck size={19}/><span><strong>Store pickup</strong><small>Confirm pickup details</small></span>
                </label>
              </fieldset>
              {form.fulfilment === "delivery" && (
                <>
                  <label>Delivery address <span className="required">*</span>
                    <textarea autoComplete="street-address" value={form.address} onChange={(e) => updateField("address", e.target.value)} placeholder="Street, area, city and state" rows={3} aria-invalid={Boolean(errors.address)}/>
                    {errors.address && <small className="field-error">{errors.address}</small>}
                  </label>
                  <label>Delivery notes <span className="optional">(optional)</span>
                    <input value={form.deliveryNotes} onChange={(e) => updateField("deliveryNotes", e.target.value)} placeholder="Landmark or helpful directions"/>
                  </label>
                </>
              )}
              <label>Order note <span className="optional">(optional)</span>
                <textarea value={form.customerNote} onChange={(e) => updateField("customerNote", e.target.value)} placeholder="Colour, model preference or questions" rows={2}/>
              </label>
              <div className="payment-note"><MessageCircle size={18}/><div><strong>Payment arranged on WhatsApp</strong><p>BridgePlus will confirm available payment methods and provide instructions. This website does not collect payment.</p></div></div>
              <button className="primary-button full-button" type="submit">Review WhatsApp order <ArrowRight size={17}/></button>
              <p className="privacy-note">Your details are included in the order message you choose to send. This prototype does not store submitted orders on a server.</p>
            </form>
          </>
        ) : (
          <div className="order-ready">
            <div className="success-icon"><Check size={28}/></div>
            <p className="eyebrow">ORDER REQUEST PREPARED</p>
            <h2 id="checkout-title">Ready for WhatsApp.</h2>
            <p className="order-reference">Reference: <strong>{generatedOrder.orderRef}</strong></p>
            <div className="status-callout"><span className="status-dot"/><div><strong>Awaiting BridgePlus confirmation</strong><p>This is not yet a confirmed order or payment.</p></div></div>
            <div className="message-preview"><pre>{generatedOrder.message}</pre></div>
            <button className="whatsapp-button full-button" onClick={() => window.open(generatedOrder.url, "_blank", "noopener,noreferrer")}><MessageCircle size={19}/> Open WhatsApp to send order</button>
            <button className="secondary-button full-button" onClick={copyOrder}><Copy size={17}/> Copy order details</button>
            {copyStatus && <p className="copy-status" role="status">{copyStatus}</p>}
            <p className="privacy-note">WhatsApp will open with this message filled in. Review it and tap Send. BridgePlus must separately confirm availability, final charges and payment instructions.</p>
            <button className="text-button full-button" onClick={() => { setGeneratedOrder(null); setCopyStatus(""); }}>Back to checkout</button>
          </div>
        )}
      </section>
    </div>
  );
}

function MobileMenu({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="mobile-menu-panel">
      <button className="mobile-menu-close" onClick={onClose}><X size={18}/> Close</button>
      {["Home", "Shop", "Phones & tablets", "Creator tech", "Computing", "Gaming", "Audio", "Smart home", "Accessories"].map((item) => (
        <a href={item === "Home" ? "#home" : "#shop"} key={item} onClick={onClose}>{item}<ChevronRight size={17}/></a>
      ))}
    </div>
  );
}

function App() {
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All products");
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toast, setToast] = useState("");

  const demoCatalog = products.some((product) => product.demo);
  const filteredProducts = useMemo(() => {
    const query = search.trim().toLowerCase();
    return products.filter((product) => {
      const categoryMatch = activeCategory === "All products" || product.category === activeCategory;
      const searchMatch = !query || [product.name, product.brand, product.category, product.description].join(" ").toLowerCase().includes(query);
      return categoryMatch && searchMatch;
    });
  }, [search, activeCategory]);

  const subtotal = cart.reduce((sum, row) => sum + row.product.price * row.quantity, 0);
  const cartCount = cart.reduce((sum, row) => sum + row.quantity, 0);

  function announce(message) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2400);
  }

  function addToCart(product) {
    setCart((old) => {
      const found = old.find((row) => row.product.id === product.id);
      return found
        ? old.map((row) => row.product.id === product.id ? { ...row, quantity: row.quantity + 1 } : row)
        : [...old, { product, quantity: 1 }];
    });
    announce(`${product.name} added to your bag`);
  }

  function changeQuantity(id, quantity) {
    if (quantity < 1) {
      setCart((old) => old.filter((row) => row.product.id !== id));
      return;
    }
    setCart((old) => old.map((row) => row.product.id === id ? { ...row, quantity: Math.min(99, quantity) } : row));
  }

  function removeFromCart(id) {
    setCart((old) => old.filter((row) => row.product.id !== id));
  }

  function startCheckout() {
    setCartOpen(false);
    setCheckoutOpen(true);
  }

  return (
    <div className="app-shell">
      <div className="announcement-bar"><Sparkles size={13}/> Premium tech. Thoughtfully chosen. <span>Explore the BridgePlus collection</span><ArrowRight size={13}/></div>
      <Header cartCount={cartCount} onOpenCart={() => setCartOpen(true)} search={search} setSearch={setSearch} onOpenMobileMenu={() => setMobileMenuOpen((v) => !v)}/>
      <MobileMenu open={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)}/>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <p className="eyebrow"><span/> SMART DEVICES <i>·</i> GREATER POSSIBILITIES</p>
            <h1>Technology that<br/><em>moves you.</em></h1>
            <p className="hero-subtitle">Discover your next favourite device.</p>
            <p className="hero-description">From everyday essentials to extraordinary creator and gaming tech, find the devices that fit your world.</p>
            <a className="primary-button hero-cta" href="#shop">Explore the collection <ArrowRight size={17}/></a>
            <div className="hero-footnote"><ShieldCheck size={16}/> Personal service from BridgePlus Tech</div>
          </div>
          <div className="hero-art" aria-label="Featured technology collection">
            <div className="hero-orb orb-one"/><div className="hero-orb orb-two"/>
            <img className="hero-image-phone" src="https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=650&q=85" alt="Smartphone" />
            <img className="hero-image-drone" src="https://images.unsplash.com/photo-1473968512647-3e447244af8f?auto=format&fit=crop&w=650&q=85" alt="Camera drone" />
            <img className="hero-image-monitor" src="https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=650&q=85" alt="Gaming monitor" />
            <div className="hero-floating-note"><span className="floating-dot"/> Discover what’s next</div>
          </div>
        </section>

        {demoCatalog && <div className="demo-banner"><CircleHelp size={17}/><span><strong>Preview catalogue:</strong> product names, prices and images are illustrative demo content. Confirm actual inventory and prices with BridgePlus before accepting customer orders.</span></div>}

        <section className="category-section section-pad" aria-labelledby="category-title">
          <div className="section-heading">
            <div><p className="eyebrow">FIND YOUR NEXT FAVOURITE</p><h2 id="category-title">Shop by category<span>.</span></h2><p>Good technology should fit naturally into your day.</p></div>
            <a className="arrow-link" href="#shop">Explore all products <ArrowRight size={16}/></a>
          </div>
          <div className="category-grid">
            {categories.filter((item) => item !== "All products").map((category) => {
              const Icon = categoryIcons[category] || ShoppingBag;
              const count = products.filter((product) => product.category === category).length;
              return <button key={category} className={`category-card ${activeCategory === category ? "category-selected" : ""}`} onClick={() => { setActiveCategory(category); setSearch(""); document.getElementById("shop")?.scrollIntoView({ behavior: "smooth" }); }}>
                <span className="category-icon"><Icon size={27} strokeWidth={1.6}/></span>
                <span className="category-card-title">{category}</span>
                <span className="category-card-bottom"><span>{count} demo item{count === 1 ? "" : "s"}</span><ArrowDownRight size={17}/></span>
              </button>;
            })}
          </div>
        </section>

        <section className="shop-section section-pad" id="shop" aria-labelledby="shop-title">
          <div className="section-heading shop-heading">
            <div><p className="eyebrow">THE BRIDGEPLUS COLLECTION</p><h2 id="shop-title">Explore the collection<span>.</span></h2><p>Useful everyday tech. Inspiring new discoveries.</p></div>
            <label className="catalog-search"><Search size={17}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find your next device..." aria-label="Search catalogue"/></label>
          </div>
          <div className="filter-row" aria-label="Filter by category">
            <div className="filter-pills">
              {categories.map((category) => <button key={category} className={`filter-pill ${activeCategory === category ? "active" : ""}`} onClick={() => setActiveCategory(category)}>{category}</button>)}
            </div>
            <span className="results-count">{filteredProducts.length} products</span>
          </div>
          {filteredProducts.length ? <div className="product-grid">{filteredProducts.map((product) => <ProductCard key={product.id} product={product} onAdd={addToCart} onView={setSelectedProduct}/>)}</div> : (
            <div className="no-results"><Search size={28}/><h3>No products found</h3><p>Try another search or choose a different category.</p><button className="secondary-button" onClick={() => {setSearch(""); setActiveCategory("All products");}}>Clear filters</button></div>
          )}
          <p className="catalog-disclaimer">Product imagery may be illustrative. Prices and availability must be confirmed by BridgePlus.</p>
        </section>

        <section className="service-strip section-pad">
          <div className="service-item"><span><Truck size={22}/></span><div><strong>Delivery or pickup</strong><p>Choose your preferred option</p></div></div>
          <div className="service-item"><span><ShieldCheck size={22}/></span><div><strong>Personal assistance</strong><p>Confirm product details with us</p></div></div>
          <div className="service-item"><span><MessageCircle size={22}/></span><div><strong>WhatsApp checkout</strong><p>Send your order request directly</p></div></div>
          <div className="service-item"><span><Headphones size={22}/></span><div><strong>Here to help</strong><p>Questions before you order?</p></div></div>
        </section>

        <section className="closing-banner section-pad">
          <div><p className="eyebrow">YOUR NEXT CHAPTER IN TECH</p><h2>Find the tech that<br/><em>feels like you.</em></h2><p>Build your selection and let BridgePlus help with the next step.</p></div>
          <a href="#shop" className="primary-button">Discover your next device <ArrowRight size={17}/></a>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <div className="footer-brand"><a className="brand-link" href="#home"><BrandMark/></a><p>Smart devices.<br/>Greater possibilities.</p><a className="footer-whatsapp" href={buildWhatsAppUrl(businessConfig.whatsappNumber, `Hello ${businessConfig.businessName}, I have a question about your products.`)} target="_blank" rel="noreferrer"><MessageCircle size={16}/> Chat with BridgePlus</a></div>
          <div className="footer-column"><h3>Explore</h3><a href="#home">Home</a><a href="#shop">Shop all</a><a href="#shop" onClick={() => setActiveCategory("Creator tech")}>Creator tech</a><a href="#shop" onClick={() => setActiveCategory("Gaming")}>Gaming</a></div>
          <div className="footer-column"><h3>Customer care</h3><button onClick={() => announce("Contact BridgePlus on WhatsApp to confirm delivery, returns and warranty terms.")}>Delivery & pickup</button><button onClick={() => announce("Ask BridgePlus to confirm warranty and return terms before ordering.")}>Warranty & returns</button><a href={buildWhatsAppUrl(businessConfig.whatsappNumber, "Hello BridgePlus, I need help with an order.")} target="_blank" rel="noreferrer">Order support</a></div>
          <div className="footer-column footer-contact"><h3>Let’s talk tech.</h3><p>Need help choosing your next device?</p><a className="footer-contact-link" href={buildWhatsAppUrl(businessConfig.whatsappNumber, "Hello BridgePlus, please help me choose a product.")} target="_blank" rel="noreferrer">Message us on WhatsApp <ArrowRight size={15}/></a><p className="footer-number">{businessConfig.supportPhone}</p></div>
        </div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} BridgePlus Tech. All rights reserved.</span><span>Orders are requests until confirmed by BridgePlus.</span><a href="#home">Back to top ↑</a></div>
      </footer>

      <button className="floating-cart" onClick={() => setCartOpen(true)} aria-label={`Open shopping bag, ${cartCount} items`}><ShoppingBag size={20}/><span>Bag</span><b>{cartCount}</b></button>
      {toast && <div className="toast" role="status"><Check size={17}/>{toast}</div>}
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} cart={cart} onChangeQuantity={changeQuantity} onRemove={removeFromCart} subtotal={subtotal} onCheckout={startCheckout}/>
      <CheckoutModal open={checkoutOpen} onClose={() => setCheckoutOpen(false)} cart={cart} subtotal={subtotal}/>
      <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} onAdd={addToCart}/>
    </div>
  );
}

export default App;