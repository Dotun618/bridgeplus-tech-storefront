export function formatMoney(amount, config) {
  return new Intl.NumberFormat(config.locale, {
    style: "currency",
    currency: config.currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function makeOrderReference() {
  const date = new Date();
  const stamp = date.toISOString().replace(/[-:TZ.]/g, "").slice(2, 12);
  const random = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `BP-${stamp}-${random}`;
}

export function normalizeWhatsAppNumber(value) {
  return String(value || "").replace(/\D/g, "");
}

export function buildWhatsAppUrl(number, message) {
  const normalized = normalizeWhatsAppNumber(number);
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
}

export function buildOrderMessage({ orderRef, form, cart, subtotal, deliveryFee, total, config }) {
  const lines = cart.map(({ product, quantity }) =>
    `• ${product.name} (${product.brand}) x${quantity} — ${formatMoney(product.price * quantity, config)}`
  );
  const deliveryLabel = form.fulfilment === "delivery" ? "Home delivery" : "Store pickup";
  return [
    `Hello ${config.businessName}, I'd like to place an order.`,
    "",
    `Order reference: ${orderRef}`,
    "Status: Awaiting BridgePlus confirmation",
    "",
    "ITEMS",
    ...lines,
    "",
    `Subtotal: ${formatMoney(subtotal, config)}`,
    `Delivery fee: ${formatMoney(deliveryFee, config)}${deliveryFee === 0 && form.fulfilment === "delivery" ? " (to be confirmed if applicable)" : ""}`,
    `TOTAL: ${formatMoney(total, config)}${deliveryFee === 0 && form.fulfilment === "delivery" ? " (before any unconfirmed delivery charge)" : ""}`,
    "",
    "CUSTOMER DETAILS",
    `Name: ${form.name.trim()}`,
    `Phone: ${form.phone.trim()}`,
    `Fulfilment: ${deliveryLabel}`,
    ...(form.fulfilment === "delivery" ? [`Delivery address: ${form.address.trim()}`, ...(form.deliveryNotes.trim() ? [`Delivery notes: ${form.deliveryNotes.trim()}`] : [])] : []),
    ...(form.customerNote.trim() ? [`Additional note: ${form.customerNote.trim()}`] : []),
    "",
    "Payment method: To be agreed with BridgePlus on WhatsApp.",
    "Please confirm product availability, final price, delivery/pickup arrangements and payment instructions.",
    "I understand this message is an order request, not a confirmed order or proof of payment.",
  ].join("\n");
}