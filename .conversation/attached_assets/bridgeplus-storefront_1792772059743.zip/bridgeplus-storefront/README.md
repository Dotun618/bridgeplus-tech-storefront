# BridgePlus Tech storefront

A custom-coded React + Vite storefront with a local shopping cart and WhatsApp-assisted checkout.

## What works

- Responsive homepage and product catalogue
- Search and category filters
- Add-to-cart, quantity controls, remove items and calculated totals
- Checkout validation
- Home delivery and store pickup
- WhatsApp message prefilled to `+234 906 737 4934`
- Copy-order fallback
- Configurable business details, delivery fee and sample catalogue
- Order status language makes clear that sending a message is not order/payment confirmation

## Important before publishing

The included catalogue contains **illustrative demo products and prices**. Replace them with BridgePlus-approved inventory, current prices, and product photos before launch. The delivery fee is set to zero by default and should be updated if BridgePlus charges one. The store does not take online payment and does not verify stock or payment.

## Run on Replit

1. Create a new Replit project using **Import from ZIP** (or upload this ZIP and extract it in a Node.js project).
2. Ensure the project root contains `package.json`, `index.html`, `vite.config.js`, and `src/`.
3. Run `npm install`.
4. Click **Run**. The command is `npm run dev`; Vite listens on `0.0.0.0`.
5. Use the preview to test adding products, checkout validation, copying the order, and opening WhatsApp.
6. Before launch, edit `src/config.js` and `src/data/products.js`.

## Run locally

Requires Node.js 18 or later.

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
npm run preview
```

## Configure business details

Edit `src/config.js`:

- `whatsappNumber`: digits only, with country code, no plus sign or spaces.
- `businessName`
- `deliveryFee`: amount in naira. Set to `0` if delivery pricing is quoted case-by-case.
- `storeAddress`: replace with the confirmed customer-facing address.
- `supportPhone`
- `currency`

## Configure products

Edit `src/data/products.js`. Each product has:

- `id`: unique string
- `name`, `brand`, `category`, `price`, `description`
- `image`: a valid image URL or a local file under `public/`
- `badge`: optional label
- `demo`: keep `true` while sample item is not verified

The app shows a demo notice while any products have `demo: true`.

## Checkout flow

1. Customer adds items and opens the cart.
2. Customer fills required details and chooses delivery or pickup.
3. The app validates the form and creates an itemised order message.
4. **Send order on WhatsApp** opens WhatsApp with the message prefilled.
5. The customer must tap Send in WhatsApp.
6. BridgePlus must separately confirm availability, final price, delivery/pickup arrangements, and payment instructions.

The app cannot know whether a WhatsApp message was actually sent or whether BridgePlus accepted the order. It therefore does not mark an order as confirmed or paid.

## Security and scope

This is a frontend prototype. It does not save orders to a database, reserve stock, authenticate administrators, or process payments. Do not collect sensitive payment credentials in the checkout. For production inventory, order tracking, admin access or automated order records, add a secure backend and database.
